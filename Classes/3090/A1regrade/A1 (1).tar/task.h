void createBoard();
void printBoard();
void* createLife(void* X);
void* spreadDeath(void* X);
void* neighborsCheck(void* X);
