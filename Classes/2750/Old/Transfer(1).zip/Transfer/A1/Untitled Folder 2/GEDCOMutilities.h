#include "GEDCOMparser.h"

void cleanseNewline(char* string);

int checkNums(char* string);

void deleteHeader(Header* tobeDeleted);

void destroyList(List tempList);
