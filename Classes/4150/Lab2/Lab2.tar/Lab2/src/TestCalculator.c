

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Calculator.h"
#include "TestCalculator.h"
#include <assert.h>

void driver(double expectedSum, double expcetedDifference, double expectedProduct, double expectedQuotient, double a, double b)
{
    return;
}

int testSubtract(double expectedResult, double a, double b, double (*subtract)(double a, double b))
{
   return 0;
}

int testAdd(double expectedResult, double a, double b, double (*add)(double a, double b))
{
    return 0;
}

int testMultiply(double expectedResult, double a, double b, double (*multilpy)(double a, double b))
{
    return 0;
}

int testDivide(double expectedResult, double a, double b, double (*divide)(double a, double b))
{
    return 0;
}
