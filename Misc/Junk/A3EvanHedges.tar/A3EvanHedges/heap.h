/**************************
	Name : Evan Hedges 
	ID: 0898140
	Date: November 5th
	Assignment: 3
***************************/

/********************************************
Purpose: Generate keys for comparison
********************************************/	
int generateKey (int heap[21][11], int row);
/********************************************
Purpose: Prints out the entire heap
********************************************/	
void printHeap(int heap[21][11]);