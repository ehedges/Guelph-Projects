/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author fsong
 */
public class SomeProgram {
    
    public static void main(String[] args) {
        if( args.length > 2)
            System.out.println(args[0] + " " + args[2] + args[1]);
    }
    
}