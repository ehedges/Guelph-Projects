
public class HelloOOP
{

    public static void main(String[] args) 
    {

        System.out.println("\nHello OOP!");

    }
}