#define MAXNAMESIZE 20
typedef struct {
	char *name;
	int grade;
} Student;

