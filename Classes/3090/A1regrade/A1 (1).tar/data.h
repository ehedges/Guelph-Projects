void createBoard();
void printBoard();
void createLife(long id);
void spreadDeath(long id);
void* gameLife(void* num);
int neighborsCheck(int i,int j);
