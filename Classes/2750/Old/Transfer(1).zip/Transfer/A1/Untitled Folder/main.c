#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parsing.h"

int main(int argc, char* argv[])
{

	createTree(argv[1]);

	return 0;
}