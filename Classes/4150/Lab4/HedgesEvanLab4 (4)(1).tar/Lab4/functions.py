##name: Patrick Di Salvo
##Date: November 1st 2nd 2019

##Do not change these functions at all

def add(x, y):
    return x+y

def product(x, y):
    return x*y

def subtract(x, y):
    return x - y
