class player

    def initialize(name)

        @name
    	@player_bag
   	@player_cup	


    end

end