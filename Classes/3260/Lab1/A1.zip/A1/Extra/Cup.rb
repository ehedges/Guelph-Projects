class cup

    def initialize()

    

    end

end