/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication9;

/**
 *
 * @author Joe
 */
public class Student {
    
    String firstName;
    String lastName;
    String address;
    
    public Student(String firstName,String LastName, String address){
    
        this.firstName = firstName;
        this.lastName = LastName;
        this.address = address;
}
    
    
}
