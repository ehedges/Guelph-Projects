#ifndef VCARD_TEST_CASES_H
#define VCARD_TEST_CASES_H

#include "TestHarness.h"

testRec* _tValidFileTest1(int testNum);
testRec* _tValidFileTest2(int testNum);
testRec* _tValidFileTest3(int testNum);
testRec* _tValidFileTest4(int testNum);
testRec* _tValidFileTest5(int testNum);
testRec* _tValidFileTest6(int testNum);
testRec* _tValidFileTest7(int testNum);
testRec* _tValidFileTest8(int testNum);
testRec* _tValidFileTest9(int testNum);
testRec* _tValidFileTest10(int testNum);
testRec* _tValidFileTest11(int testNum);
testRec* _tValidFileTest12(int testNum);
testRec* _tValidFileTest13(int testNum);
testRec* _tValidFileTest14(int testNum);
testRec* _tValidFileTest15(int testNum);
testRec* _tValidFileTest16(int testNum);
testRec* _tValidFileTest17(int testNum);
testRec* _tValidFileTest18(int testNum);
testRec* _tValidFileTest19(int testNum);
testRec* _tValidFileTest20(int testNum);

testRec* _tInvalidFileTests(int testNum);
testRec* _tInvalidCardTests(int testNum);
testRec* _tInvalidPropTests(int testNum);

testRec* _tDeleteCardTests(int testNum);

testRec* _tPrintCardTests(int testNum);

testRec* _tPrintCardErrorTest(int testNum);

#endif
