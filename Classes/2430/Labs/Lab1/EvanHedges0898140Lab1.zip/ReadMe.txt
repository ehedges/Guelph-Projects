Greetings marker of Evan Hedges, 0898140, Lab 1.
To run this program you must extract the zip file and 
use the command prompt to navigate to the location of the program.
Type javac.exe HelloOOP.java to compile the program.
Type java.exe HelloOOP.

Limitations:
Nothing.

Date: Tuesday 15th, 2015.
Evan Hedges 0898140.